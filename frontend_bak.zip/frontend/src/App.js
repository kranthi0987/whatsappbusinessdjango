import React from 'react';
import logo from './logo.svg';
import './App.css';
import Login from './components/auth/Login';
import ReactDOM from "react-dom";
import {BrowserRouter, Route, Switch} from "react-router-dom";
import Header from "./components/layouts/Header/Header";
import SideBar from "./components/layouts/Sidebar/Sidebar";
import Content from "./components/layouts/Content/Content";

function App() {
    return (
        <div>
            {/*<Header />*/}
            {/*<SideBar />*/}
            {/*<Content />*/}
            <Login />
        </div>
    );

}

export default App;

